﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace berp12345
{
    internal class FirstName
    {
        public string FName { get; set; }

        public bool IsFemale { get; set; }

        public FirstName(string fname)
        {
            this.FName = fname;
            CheckIsFemale();
        }
        public void CheckIsFemale()
        {
            IsFemale = (FName[FName.Length - 1] == 'a') || (FName[FName.Length - 1] == 'A');

        }

    }


    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
            List<FirstName> list = new List<FirstName>();
            list.Add(new FirstName("Anna"));
            list.Add(new FirstName("Marek"));
            list.Add(new FirstName("Jan"));
            list.Add(new FirstName("Ewa"));
            this.DataContext = list;




        }
    }
}